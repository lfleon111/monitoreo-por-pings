<?php

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <title>Monitoreo de sucursales</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
<center><h3>Conexion de sucursales</h3></center><hr><br>

<center>
	<div id="result"></div>
  <div id="result1"></div>
</center>

<script type="text/javascript">
function getip()
{
$.ajax({
    url: 'get.php',
    data: {
       type: 'highway',
       id: 61
    },
    cache: false, // es 'true' por defecto a menos que type sea 'jsonp' o 'script'
    type: 'get',
    success: function(data){
       // alert(data);
        document.getElementById("result").innerHTML =data;
    }
});
}

setInterval(getip,1000);
// jQuery envía una petici
</script>




</body>

</html>