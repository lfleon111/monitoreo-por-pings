<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Monitoreo de trafico</title> 
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container-fluid" style="margin-top:-40px;">
<?php
ini_set('max_execution_time', 0);
$ip = "10.28.1.1";

$bytes_paq =rand(32, 90);

$output = shell_exec("ping -n 3 -w 1 -l $bytes_paq $ip ");

$resultado="";
$te= explode("con", $output);
$te1 = explode("datos:", $te[1]);
$bytes=$te1[0]." datos.";
$detalle=$te1[0];

switch (true) {
  case !strpos($output, "enviados = 0") && !strpos($output, "recibidos = 0") && strpos($output, "perdidos = 0") || strpos($output, "perdidos = 1"): $resultado='Conectado'; $status="table-success"; $img="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Bueno-verde.png/234px-Bueno-verde.png"; break;

  case strpos($output, "perdidos = 1") || strpos($output, "perdidos = 2"): $resultado='Intermitente'; $status="table-warning"; $img="https://img2.freepng.es/20180319/dbq/kisspng-incandescent-light-bulb-electric-light-compact-flu-hd-lightbulb-png-5ab02bb0b01d28.5110390615214949607214.jpg"; break;

  case strpos($output, "Tiempo de espera agotado para esta solicitud") || strpos($output, "inaccesible") || strpos($output, "perdidos = 3"):: $resultado='No Conectado'; $status="table-danger"; $img="https://cdn.pixabay.com/photo/2012/04/12/20/12/x-30465_960_720.png"; break;
}

switch (true) {
  case strpos($output, "perdidos = 0"): $nivel="100%"; $prog="bg-success"; break;
  case strpos($output, "perdidos = 1"): $nivel="90%"; $prog="bg-info"; break;
  case strpos($output, "perdidos = 2"): $nivel="48%"; $prog="bg-warning"; break;
  case strpos($output, "perdidos = 3"): $nivel="0%"; $prog="bg-danger"; break;
}
/*
$detalle = "haciendo ping a: " . $ip . "  Estatus: <strong> " . $resultado . " </strong>";
$detalle1 = "Estatus: <strong> " . $resultado . " </strong>";
*/
?>



<div class="row">
<div class="col">
              <div class="card card-stats <?php echo$prog; ?>">
                <div class="card-header card-header-warning card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons"><?php echo$nivel; ?></i>
                  </div>
                  <p class="card-category"><?php echo$bytes; ?></p>
                  <h3 class="card-title"><strong style="color:#ffffff;">CEDIS (10.28.1.1)</strong><small></small>
                  </h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <i class="material-icons">Estado:</i>
                    <strong><?php echo$resultado; ?></strong>
                  </div>
                </div>
              </div>
  </div>




<!--------------------------------------------------- UNO -------------------------------------------------------------------->



<?php
ini_set('max_execution_time', 0);
$ip = "10.15.1.1";

$output = shell_exec("ping -n 3 -w 1 -l $bytes_paq $ip ");

$resultado="";
$te= explode("con", $output);
$te1 = explode("datos:", $te[1]);
$bytes=$te1[0]." datos.";
$detalle=$te1[0];

switch (true) {
  case !strpos($output, "enviados = 0") && !strpos($output, "recibidos = 0") && strpos($output, "perdidos = 0") || strpos($output, "perdidos = 1"): $resultado='Conectado'; $status="table-success"; $img="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Bueno-verde.png/234px-Bueno-verde.png"; break;

  case strpos($output, "perdidos = 1") || strpos($output, "perdidos = 2"): $resultado='Intermitente'; $status="table-warning"; $img="https://img2.freepng.es/20180319/dbq/kisspng-incandescent-light-bulb-electric-light-compact-flu-hd-lightbulb-png-5ab02bb0b01d28.5110390615214949607214.jpg"; break;

  case strpos($output, "Tiempo de espera agotado para esta solicitud") || strpos($output, "inaccesible") || strpos($output, "perdidos = 3"):: $resultado='No Conectado'; $status="table-danger"; $img="https://cdn.pixabay.com/photo/2012/04/12/20/12/x-30465_960_720.png"; break;
}

switch (true) {
  case strpos($output, "perdidos = 0"): $nivel="100%"; $prog="bg-success"; break;
  case strpos($output, "perdidos = 1"): $nivel="90%"; $prog="bg-info"; break;
  case strpos($output, "perdidos = 2"): $nivel="48%"; $prog="bg-warning"; break;
  case strpos($output, "perdidos = 3"): $nivel="0%"; $prog="bg-danger"; break;
}
/*
$detalle = "haciendo ping a: " . $ip . "  Estatus: <strong> " . $resultado . " </strong>";
$detalle1 = "Estatus: <strong> " . $resultado . " </strong>";
*/
?>




<div class="col">
              <div class="card card-stats <?php echo$prog; ?>">
                <div class="card-header card-header-warning card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons"><?php echo$nivel; ?></i>
                  </div>
                  <p class="card-category"><?php echo$bytes; ?></p>
                  <h3 class="card-title"><strong style="color:#ffffff;">MERIDA (10.15.1.1)</strong><small></small>
                  </h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <i class="material-icons">Estado:</i>
                    <strong><?php echo$resultado; ?></strong>
                  </div>
                </div>
              </div>
  </div>
  



<!--------------------------------------------------- UNO -------------------------------------------------------------------->



<?php
ini_set('max_execution_time', 0);
$ip = "10.27.1.1";
$output = shell_exec("ping -n 3 -w 1 -l $bytes_paq $ip ");

$resultado="";
$te= explode("con", $output);
$te1 = explode("datos:", $te[1]);
$bytes=$te1[0]." datos.";
$detalle=$te1[0];

switch (true) {
  case !strpos($output, "enviados = 0") && !strpos($output, "recibidos = 0") && strpos($output, "perdidos = 0") || strpos($output, "perdidos = 1"): $resultado='Conectado'; $status="table-success"; $img="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Bueno-verde.png/234px-Bueno-verde.png"; break;

  case strpos($output, "perdidos = 1") || strpos($output, "perdidos = 2"): $resultado='Intermitente'; $status="table-warning"; $img="https://img2.freepng.es/20180319/dbq/kisspng-incandescent-light-bulb-electric-light-compact-flu-hd-lightbulb-png-5ab02bb0b01d28.5110390615214949607214.jpg"; break;

  case strpos($output, "Tiempo de espera agotado para esta solicitud") || strpos($output, "inaccesible") || strpos($output, "perdidos = 3"):: $resultado='No Conectado'; $status="table-danger"; $img="https://cdn.pixabay.com/photo/2012/04/12/20/12/x-30465_960_720.png"; break;
}

switch (true) {
  case strpos($output, "perdidos = 0"): $nivel="100%"; $prog="bg-success"; break;
  case strpos($output, "perdidos = 1"): $nivel="90%"; $prog="bg-info"; break;
  case strpos($output, "perdidos = 2"): $nivel="48%"; $prog="bg-warning"; break;
  case strpos($output, "perdidos = 3"): $nivel="0%"; $prog="bg-danger"; break;
}
/*
$detalle = "haciendo ping a: " . $ip . "  Estatus: <strong> " . $resultado . " </strong>";
$detalle1 = "Estatus: <strong> " . $resultado . " </strong>";
*/
?>




<div class="col">
              <div class="card card-stats <?php echo$prog; ?>">
                <div class="card-header card-header-warning card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons"><?php echo$nivel; ?></i>
                  </div>
                  <p class="card-category"><?php echo$bytes; ?></p>
                  <h3 class="card-title"><strong style="color:#ffffff;">QRO (10.27.1.1)</strong><small></small>
                  </h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <i class="material-icons">Estado:</i>
                    <strong><?php echo$resultado; ?></strong>
                  </div>
                </div>
              </div>
  </div>
  



<!--------------------------------------------------- UNO -------------------------------------------------------------------->



<?php
ini_set('max_execution_time', 0);
$ip = "10.19.1.1";
$output = shell_exec("ping -n 3 -w 1 -l $bytes_paq $ip ");

$resultado="";
$te= explode("con", $output);
$te1 = explode("datos:", $te[1]);
$bytes=$te1[0]." datos.";
$detalle=$te1[0];

switch (true) {
  case !strpos($output, "enviados = 0") && !strpos($output, "recibidos = 0") && strpos($output, "perdidos = 0") || strpos($output, "perdidos = 1"): $resultado='Conectado'; $status="table-success"; $img="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Bueno-verde.png/234px-Bueno-verde.png"; break;

  case strpos($output, "perdidos = 1") || strpos($output, "perdidos = 2"): $resultado='Intermitente'; $status="table-warning"; $img="https://img2.freepng.es/20180319/dbq/kisspng-incandescent-light-bulb-electric-light-compact-flu-hd-lightbulb-png-5ab02bb0b01d28.5110390615214949607214.jpg"; break;

  case strpos($output, "Tiempo de espera agotado para esta solicitud") || strpos($output, "inaccesible") || strpos($output, "perdidos = 3"):: $resultado='No Conectado'; $status="table-danger"; $img="https://cdn.pixabay.com/photo/2012/04/12/20/12/x-30465_960_720.png"; break;
}

switch (true) {
  case strpos($output, "perdidos = 0"): $nivel="100%"; $prog="bg-success"; break;
  case strpos($output, "perdidos = 1"): $nivel="90%"; $prog="bg-info"; break;
  case strpos($output, "perdidos = 2"): $nivel="48%"; $prog="bg-warning"; break;
  case strpos($output, "perdidos = 3"): $nivel="0%"; $prog="bg-danger"; break;
}
/*
$detalle = "haciendo ping a: " . $ip . "  Estatus: <strong> " . $resultado . " </strong>";
$detalle1 = "Estatus: <strong> " . $resultado . " </strong>";
*/
?>




<div class="col">
              <div class="card card-stats <?php echo$prog; ?>">
                <div class="card-header card-header-warning card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons"><?php echo$nivel; ?></i>
                  </div>
                  <p class="card-category"><?php echo$bytes; ?></p>
                  <h3 class="card-title"><strong style="color:#ffffff;">PUEBLA (10.19.1.1)</strong><small></small>
                  </h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <i class="material-icons">Estado:</i>
                    <strong><?php echo$resultado; ?></strong>
                  </div>
                </div>
              </div>
  </div>
  
</div>



<!--------------------------------------------------- UNO -------------------------------------------------------------------->




<?php
ini_set('max_execution_time', 0);
$ip = "10.14.1.1";
$output = shell_exec("ping -n 3 -w 1 -l $bytes_paq $ip ");

$resultado="";
$te= explode("con", $output);
$te1 = explode("datos:", $te[1]);
$bytes=$te1[0]." datos.";
$detalle=$te1[0];

switch (true) {
  case !strpos($output, "enviados = 0") && !strpos($output, "recibidos = 0") && strpos($output, "perdidos = 0") || strpos($output, "perdidos = 1"): $resultado='Conectado'; $status="table-success"; $img="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Bueno-verde.png/234px-Bueno-verde.png"; break;

  case strpos($output, "perdidos = 1") || strpos($output, "perdidos = 2"): $resultado='Intermitente'; $status="table-warning"; $img="https://img2.freepng.es/20180319/dbq/kisspng-incandescent-light-bulb-electric-light-compact-flu-hd-lightbulb-png-5ab02bb0b01d28.5110390615214949607214.jpg"; break;

  case strpos($output, "Tiempo de espera agotado para esta solicitud") || strpos($output, "inaccesible") || strpos($output, "perdidos = 3"):: $resultado='No Conectado'; $status="table-danger"; $img="https://cdn.pixabay.com/photo/2012/04/12/20/12/x-30465_960_720.png"; break;
}

switch (true) {
  case strpos($output, "perdidos = 0"): $nivel="100%"; $prog="bg-success"; break;
  case strpos($output, "perdidos = 1"): $nivel="90%"; $prog="bg-info"; break;
  case strpos($output, "perdidos = 2"): $nivel="48%"; $prog="bg-warning"; break;
  case strpos($output, "perdidos = 3"): $nivel="0%"; $prog="bg-danger"; break;
}
/*
$detalle = "haciendo ping a: " . $ip . "  Estatus: <strong> " . $resultado . " </strong>";
$detalle1 = "Estatus: <strong> " . $resultado . " </strong>";
*/
?>

<br>

<div class="row">
<div class="col">
              <div class="card card-stats <?php echo$prog; ?>">
                <div class="card-header card-header-warning card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons"><?php echo$nivel; ?></i>
                  </div>
                  <p class="card-category"><?php echo$bytes; ?></p>
                  <h3 class="card-title"><strong style="color:#ffffff;">LEON (10.14.1.1)</strong><small></small>
                  </h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <i class="material-icons">Estado:</i>
                    <strong><?php echo$resultado; ?></strong>
                  </div>
                </div>
              </div>
  </div>



<!--------------------------------------------------- UNO -------------------------------------------------------------------->







<?php
ini_set('max_execution_time', 0);
$ip = "10.16.1.1";
$output = shell_exec("ping -n 3 -w 1 -l $bytes_paq $ip ");

$resultado="";
$te= explode("con", $output);
$te1 = explode("datos:", $te[1]);
$bytes=$te1[0]." datos.";
$detalle=$te1[0];

switch (true) {
  case !strpos($output, "enviados = 0") && !strpos($output, "recibidos = 0") && strpos($output, "perdidos = 0") || strpos($output, "perdidos = 1"): $resultado='Conectado'; $status="table-success"; $img="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Bueno-verde.png/234px-Bueno-verde.png"; break;

  case strpos($output, "perdidos = 1") || strpos($output, "perdidos = 2"): $resultado='Intermitente'; $status="table-warning"; $img="https://img2.freepng.es/20180319/dbq/kisspng-incandescent-light-bulb-electric-light-compact-flu-hd-lightbulb-png-5ab02bb0b01d28.5110390615214949607214.jpg"; break;

  case strpos($output, "Tiempo de espera agotado para esta solicitud") || strpos($output, "inaccesible") || strpos($output, "perdidos = 3"):: $resultado='No Conectado'; $status="table-danger"; $img="https://cdn.pixabay.com/photo/2012/04/12/20/12/x-30465_960_720.png"; break;
}

switch (true) {
  case strpos($output, "perdidos = 0"): $nivel="100%"; $prog="bg-success"; break;
  case strpos($output, "perdidos = 1"): $nivel="90%"; $prog="bg-info"; break;
  case strpos($output, "perdidos = 2"): $nivel="48%"; $prog="bg-warning"; break;
  case strpos($output, "perdidos = 3"): $nivel="0%"; $prog="bg-danger"; break;
}
/*
$detalle = "haciendo ping a: " . $ip . "  Estatus: <strong> " . $resultado . " </strong>";
$detalle1 = "Estatus: <strong> " . $resultado . " </strong>";
*/
?>




<div class="col">
              <div class="card card-stats <?php echo$prog; ?>">
                <div class="card-header card-header-warning card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons"><?php echo$nivel; ?></i>
                  </div>
                  <p class="card-category"><?php echo$bytes; ?></p>
                  <h3 class="card-title"><strong style="color:#ffffff;">MTY (10.16.1.1)</strong><small></small>
                  </h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <i class="material-icons">Estado:</i>
                    <strong><?php echo$resultado; ?></strong>
                  </div>
                </div>
              </div>
  </div>



<!--------------------------------------------------- UNO -------------------------------------------------------------------->









<?php
ini_set('max_execution_time', 0);
$ip = "10.12.1.1";
$output = shell_exec("ping -n 3 -w 1 -l $bytes_paq $ip ");

$resultado="";
$te= explode("con", $output);
$te1 = explode("datos:", $te[1]);
$bytes=$te1[0]." datos.";
$detalle=$te1[0];

switch (true) {
  case !strpos($output, "enviados = 0") && !strpos($output, "recibidos = 0") && strpos($output, "perdidos = 0") || strpos($output, "perdidos = 1"): $resultado='Conectado'; $status="table-success"; $img="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Bueno-verde.png/234px-Bueno-verde.png"; break;

  case strpos($output, "perdidos = 1") || strpos($output, "perdidos = 2"): $resultado='Intermitente'; $status="table-warning"; $img="https://img2.freepng.es/20180319/dbq/kisspng-incandescent-light-bulb-electric-light-compact-flu-hd-lightbulb-png-5ab02bb0b01d28.5110390615214949607214.jpg"; break;

  case strpos($output, "Tiempo de espera agotado para esta solicitud") || strpos($output, "inaccesible") || strpos($output, "perdidos = 3"):: $resultado='No Conectado'; $status="table-danger"; $img="https://cdn.pixabay.com/photo/2012/04/12/20/12/x-30465_960_720.png"; break;
}

switch (true) {
  case strpos($output, "perdidos = 0"): $nivel="100%"; $prog="bg-success"; break;
  case strpos($output, "perdidos = 1"): $nivel="90%"; $prog="bg-info"; break;
  case strpos($output, "perdidos = 2"): $nivel="48%"; $prog="bg-warning"; break;
  case strpos($output, "perdidos = 3"): $nivel="0%"; $prog="bg-danger"; break;
}
/*
$detalle = "haciendo ping a: " . $ip . "  Estatus: <strong> " . $resultado . " </strong>";
$detalle1 = "Estatus: <strong> " . $resultado . " </strong>";
*/
?>



<div class="col">
              <div class="card card-stats <?php echo$prog; ?>">
                <div class="card-header card-header-warning card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons"><?php echo$nivel; ?></i>
                  </div>
                  <p class="card-category"><?php echo$bytes; ?></p>
                  <h3 class="card-title"><strong style="color:#ffffff;">GDL (10.12.1.1)</strong><small></small>
                  </h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <i class="material-icons">Estado:</i>
                    <strong><?php echo$resultado; ?></strong>
                  </div>
                </div>
              </div>
  </div>



<!--------------------------------------------------- UNO -------------------------------------------------------------------->






<?php
ini_set('max_execution_time', 0);
$ip = "10.10.1.1";
$output = shell_exec("ping -n 3 -w 1 -l $bytes_paq $ip ");

$resultado="";
$te= explode("con", $output);
$te1 = explode("datos:", $te[1]);
$bytes=$te1[0]." datos.";
$detalle=$te1[0];

switch (true) {
  case !strpos($output, "enviados = 0") && !strpos($output, "recibidos = 0") && strpos($output, "perdidos = 0") || strpos($output, "perdidos = 1"): $resultado='Conectado'; $status="table-success"; $img="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Bueno-verde.png/234px-Bueno-verde.png"; break;

  case strpos($output, "perdidos = 1") || strpos($output, "perdidos = 2"): $resultado='Intermitente'; $status="table-warning"; $img="https://img2.freepng.es/20180319/dbq/kisspng-incandescent-light-bulb-electric-light-compact-flu-hd-lightbulb-png-5ab02bb0b01d28.5110390615214949607214.jpg"; break;

  case strpos($output, "Tiempo de espera agotado para esta solicitud") || strpos($output, "inaccesible") || strpos($output, "perdidos = 3"):: $resultado='No Conectado'; $status="table-danger"; $img="https://cdn.pixabay.com/photo/2012/04/12/20/12/x-30465_960_720.png"; break;
}

switch (true) {
  case strpos($output, "perdidos = 0"): $nivel="100%"; $prog="bg-success"; break;
  case strpos($output, "perdidos = 1"): $nivel="90%"; $prog="bg-info"; break;
  case strpos($output, "perdidos = 2"): $nivel="48%"; $prog="bg-warning"; break;
  case strpos($output, "perdidos = 3"): $nivel="0%"; $prog="bg-danger"; break;
}
/*
$detalle = "haciendo ping a: " . $ip . "  Estatus: <strong> " . $resultado . " </strong>";
$detalle1 = "Estatus: <strong> " . $resultado . " </strong>";
*/
?>




<div class="col">
              <div class="card card-stats <?php echo$prog; ?>">
                <div class="card-header card-header-warning card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons"><?php echo$nivel; ?></i>
                  </div>
                  <p class="card-category"><?php echo$bytes; ?></p>
                  <h3 class="card-title"><strong style="color:#ffffff;">CHIH (10.10.1.1)</strong><small></small>
                  </h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <i class="material-icons">Estado:</i>
                    <strong><?php echo$resultado; ?></strong>
                  </div>
                </div>
              </div>
  </div>
</div>



<!--------------------------------------------------- UNO -------------------------------------------------------------------->






<?php
ini_set('max_execution_time', 0);
$ip = "10.11.1.1";
$output = shell_exec("ping -n 3 -w 1 -l $bytes_paq $ip ");

$resultado="";
$te= explode("con", $output);
$te1 = explode("datos:", $te[1]);
$bytes=$te1[0]." datos.";
$detalle=$te1[0];

switch (true) {
  case !strpos($output, "enviados = 0") && !strpos($output, "recibidos = 0") && strpos($output, "perdidos = 0") || strpos($output, "perdidos = 1"): $resultado='Conectado'; $status="table-success"; $img="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Bueno-verde.png/234px-Bueno-verde.png"; break;

  case strpos($output, "perdidos = 1") || strpos($output, "perdidos = 2"): $resultado='Intermitente'; $status="table-warning"; $img="https://img2.freepng.es/20180319/dbq/kisspng-incandescent-light-bulb-electric-light-compact-flu-hd-lightbulb-png-5ab02bb0b01d28.5110390615214949607214.jpg"; break;

  case strpos($output, "Tiempo de espera agotado para esta solicitud") || strpos($output, "inaccesible") || strpos($output, "perdidos = 3"):: $resultado='No Conectado'; $status="table-danger"; $img="https://cdn.pixabay.com/photo/2012/04/12/20/12/x-30465_960_720.png"; break;
}

switch (true) {
  case strpos($output, "perdidos = 0"): $nivel="100%"; $prog="bg-success"; break;
  case strpos($output, "perdidos = 1"): $nivel="90%"; $prog="bg-info"; break;
  case strpos($output, "perdidos = 2"): $nivel="48%"; $prog="bg-warning"; break;
  case strpos($output, "perdidos = 3"): $nivel="0%"; $prog="bg-danger"; break;
}
/*
$detalle = "haciendo ping a: " . $ip . "  Estatus: <strong> " . $resultado . " </strong>";
$detalle1 = "Estatus: <strong> " . $resultado . " </strong>";
*/
?>

<br>

<div class="row">
<div class="col">
              <div class="card card-stats <?php echo$prog; ?>">
                <div class="card-header card-header-warning card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons"><?php echo$nivel; ?></i>
                  </div>
                  <p class="card-category"><?php echo$bytes; ?></p>
                  <h3 class="card-title"><strong style="color:#ffffff;">CULIACAN (10.11.1.1)</strong><small></small>
                  </h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <i class="material-icons">Estado:</i>
                    <strong><?php echo$resultado; ?></strong>
                  </div>
                </div>
              </div>
  </div>



<!--------------------------------------------------- UNO -------------------------------------------------------------------->









<?php
ini_set('max_execution_time', 0);
$ip = "10.10.1.1";
$output = shell_exec("ping -n 3 -w 1 -l $bytes_paq $ip ");

$resultado="";
$te= explode("con", $output);
$te1 = explode("datos:", $te[1]);
$bytes=$te1[0]." datos.";
$detalle=$te1[0];

switch (true) {
  case !strpos($output, "enviados = 0") && !strpos($output, "recibidos = 0") && strpos($output, "perdidos = 0") || strpos($output, "perdidos = 1"): $resultado='Conectado'; $status="table-success"; $img="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Bueno-verde.png/234px-Bueno-verde.png"; break;

  case strpos($output, "perdidos = 1") || strpos($output, "perdidos = 2"): $resultado='Intermitente'; $status="table-warning"; $img="https://img2.freepng.es/20180319/dbq/kisspng-incandescent-light-bulb-electric-light-compact-flu-hd-lightbulb-png-5ab02bb0b01d28.5110390615214949607214.jpg"; break;

  case strpos($output, "Tiempo de espera agotado para esta solicitud") || strpos($output, "inaccesible") || strpos($output, "perdidos = 3"):: $resultado='No Conectado'; $status="table-danger"; $img="https://cdn.pixabay.com/photo/2012/04/12/20/12/x-30465_960_720.png"; break;
}

switch (true) {
  case strpos($output, "perdidos = 0"): $nivel="100%"; $prog="bg-success"; break;
  case strpos($output, "perdidos = 1"): $nivel="90%"; $prog="bg-info"; break;
  case strpos($output, "perdidos = 2"): $nivel="48%"; $prog="bg-warning"; break;
  case strpos($output, "perdidos = 3"): $nivel="0%"; $prog="bg-danger"; break;
}
/*
$detalle = "haciendo ping a: " . $ip . "  Estatus: <strong> " . $resultado . " </strong>";
$detalle1 = "Estatus: <strong> " . $resultado . " </strong>";
*/
?>




<div class="col">
              <div class="card card-stats <?php echo$prog; ?>">
                <div class="card-header card-header-warning card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons"><?php echo$nivel; ?></i>
                  </div>
                  <p class="card-category"><?php echo$bytes; ?></p>
                  <h3 class="card-title"><strong style="color:#ffffff;">HERMOSILLO (10.18.1.1)</strong><small></small>
                  </h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <i class="material-icons">Estado:</i>
                    <strong><?php echo$resultado; ?></strong>
                  </div>
                </div>
              </div>
  </div>




<!--------------------------------------------------- UNO -------------------------------------------------------------------->





<?php
ini_set('max_execution_time', 0);
$ip = "10.21.1.1";
$output = shell_exec("ping -n 3 -w 1 -l $bytes_paq $ip ");

$resultado="";
$te= explode("con", $output);
$te1 = explode("datos:", $te[1]);
$bytes=$te1[0]." datos.";
$detalle=$te1[0];

switch (true) {
  case !strpos($output, "enviados = 0") && !strpos($output, "recibidos = 0") && strpos($output, "perdidos = 0") || strpos($output, "perdidos = 1"): $resultado='Conectado'; $status="table-success"; $img="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Bueno-verde.png/234px-Bueno-verde.png"; break;

  case strpos($output, "perdidos = 1") || strpos($output, "perdidos = 2"): $resultado='Intermitente'; $status="table-warning"; $img="https://img2.freepng.es/20180319/dbq/kisspng-incandescent-light-bulb-electric-light-compact-flu-hd-lightbulb-png-5ab02bb0b01d28.5110390615214949607214.jpg"; break;

  case strpos($output, "Tiempo de espera agotado para esta solicitud") || strpos($output, "inaccesible") || strpos($output, "perdidos = 3"):: $resultado='No Conectado'; $status="table-danger"; $img="https://cdn.pixabay.com/photo/2012/04/12/20/12/x-30465_960_720.png"; break;
}

switch (true) {
  case strpos($output, "perdidos = 0"): $nivel="100%"; $prog="bg-success"; break;
  case strpos($output, "perdidos = 1"): $nivel="90%"; $prog="bg-info"; break;
  case strpos($output, "perdidos = 2"): $nivel="48%"; $prog="bg-warning"; break;
  case strpos($output, "perdidos = 3"): $nivel="0%"; $prog="bg-danger"; break;
}
/*
$detalle = "haciendo ping a: " . $ip . "  Estatus: <strong> " . $resultado . " </strong>";
$detalle1 = "Estatus: <strong> " . $resultado . " </strong>";
*/
?>




<div class="col">
              <div class="card card-stats <?php echo$prog; ?>">
                <div class="card-header card-header-warning card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons"><?php echo$nivel; ?></i>
                  </div>
                  <p class="card-category"><?php echo$bytes; ?></p>
                  <h3 class="card-title"><strong style="color:#ffffff;">TIJUANA (10.21.1.1)</strong><small></small>
                  </h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <i class="material-icons">Estado:</i>
                    <strong><?php echo$resultado; ?></strong>
                  </div>
                </div>
              </div>
  </div>

</div>
</div>
</body>
</html>


<!--------------------------------------------------- UNO -------------------------------------------------------------------->
